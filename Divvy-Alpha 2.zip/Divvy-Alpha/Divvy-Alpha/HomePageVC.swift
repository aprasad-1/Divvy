//
//  HomePageVC.swift
//  Divvy-Alpha
//

import UIKit
import FirebaseAuth
import PhotosUI

class HomePageVC: UIViewController,UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var profilePic: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            title: "Sign Out",
            style: .plain,
            target: self,
            action: #selector(signOutTapped)
        )
        
        profilePic.layer.cornerRadius = profilePic.frame.height / 2
        profilePic.clipsToBounds = true
    }

    @objc private func signOutTapped() {
        try? Auth.auth().signOut()
        // Back to Sign In (clear stack)
        if let signIn = storyboard?.instantiateViewController(withIdentifier: "SignInVC") as? SignInVC {
            navigationController?.setViewControllers([signIn], animated: true)
        } else {
            navigationController?.popToRootViewController(animated: true)
        }
    }
    
    @IBAction func editProfile(_ sender: Any) {
        // Create alert for user options
        let alert = UIAlertController(title: "Edit Profile Picture", message: nil, preferredStyle: .actionSheet)
                
                // Choose from Library
        alert.addAction(UIAlertAction(title: "Choose from Library", style: .default, handler: { _ in
            let picker = UIImagePickerController()
            picker.sourceType = .photoLibrary
            picker.delegate = self
            picker.allowsEditing = true
            self.present(picker, animated: true)
        }))
                
                // Take Photo (if available)
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            alert.addAction(UIAlertAction(title: "Take Photo", style: .default, handler: { _ in
                let picker = UIImagePickerController()
                picker.sourceType = .camera
                picker.delegate = self
                picker.allowsEditing = true
                self.present(picker, animated: true)
            }))
        }

        // Cancel button
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))

        // Present the options
        present(alert, animated: true)
    }
    
    func imagePickerController(_ picker: UIImagePickerController,
                                   didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let editedImage = info[.editedImage] as? UIImage {
                profilePic.image = editedImage
            } else if let originalImage = info[.originalImage] as? UIImage {
                profilePic.image = originalImage
            }
            dismiss(animated: true)
        }
}
