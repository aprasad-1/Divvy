//
//  HomePageVC.swift
//  Divvy-Alpha
//

import UIKit
import FirebaseAuth
import FirebaseFirestore

class HomePageVC: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var profilePic: UIImageView!

    private let db = Firestore.firestore()
    private var profileListener: ListenerRegistration?

    override func viewDidLoad() {
        super.viewDidLoad()

        navigationItem.rightBarButtonItem = UIBarButtonItem(
            title: "Sign Out",
            style: .plain,
            target: self,
            action: #selector(signOutTapped)
        )

        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            self.profilePic.layer.cornerRadius = self.profilePic.bounds.height / 2.0
            self.profilePic.clipsToBounds = true
        }

        // Show Auth values immediately while Firestore loads
        if let user = Auth.auth().currentUser {
            self.emailLabel.text = user.email
            self.nameLabel.text  = user.displayName ?? ""
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        guard let uid = Auth.auth().currentUser?.uid else {
            goToSignIn(); return
        }

        profileListener?.remove()
        profileListener = db.collection("users").document(uid)
            .addSnapshotListener { [weak self] snap, error in
                guard let self = self else { return }
                if let error = error { print("Profile listener error:", error); return }
                guard let data = snap?.data() else { return }

                let name  = (data["name"] as? String) ?? ""
                let email = (data["email"] as? String) ?? Auth.auth().currentUser?.email ?? ""

                DispatchQueue.main.async {
                    self.nameLabel.text = name
                    self.emailLabel.text = email
                }
            }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        profileListener?.remove()
        profileListener = nil
    }

    @objc private func signOutTapped() {
        try? Auth.auth().signOut()
        goToSignIn()
    }

    private func goToSignIn() {
        if let signIn = storyboard?.instantiateViewController(withIdentifier: "SignInVC") as? SignInVC {
            navigationController?.setViewControllers([signIn], animated: true)
        } else {
            navigationController?.popToRootViewController(animated: true)
        }
    }

    // image picker code unchanged...
}
