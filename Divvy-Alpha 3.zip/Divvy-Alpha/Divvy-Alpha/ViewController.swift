//
//  ViewController.swift  (Sign Up)
//  Divvy-Alpha
//

import UIKit
import FirebaseAuth
import FirebaseFirestore

class ViewController: UIViewController {

    // Hook these up in Interface Builder
    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var signUpButton: UIButton!
    @IBOutlet weak var signInLinkButton: UIButton!

    private let spinner = UIActivityIndicatorView(style: .medium)
    private let db = Firestore.firestore()

    override func viewDidLoad() {
        super.viewDidLoad()

        passwordField.isSecureTextEntry = true
        spinner.hidesWhenStopped = true
        spinner.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(spinner)
        NSLayoutConstraint.activate([
            spinner.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            spinner.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
    }

    // 🚫 Remove this to avoid auto-pushing again and causing doubles
    // override func viewDidAppear(_ animated: Bool) { ... }

    // MARK: - Actions

    @IBAction func signUpTapped(_ sender: UIButton) {
        view.endEditing(true)

        guard let name = nameField.text?.trimmingCharacters(in: .whitespacesAndNewlines), !name.isEmpty,
              let email = emailField.text?.trimmingCharacters(in: .whitespacesAndNewlines), !email.isEmpty,
              let password = passwordField.text, !password.isEmpty else {
            return alert("Please fill in name, email, and password.")
        }
        guard password.count >= 6 else { return alert("Password must be at least 6 characters.") }

        setLoading(true)
        Auth.auth().createUser(withEmail: email, password: password) { [weak self] result, error in
            guard let self = self else { return }
            if let error = error {
                self.setLoading(false)
                return self.alert(self.mapAuthError(error))
            }
            guard let user = result?.user else {
                self.setLoading(false)
                return self.alert("Could not create user.")
            }

            // 1) Set Auth displayName
            let change = user.createProfileChangeRequest()
            change.displayName = name
            change.commitChanges { _ in
                // Optional: force refresh of the currentUser
                user.reload { _ in }
            }

            // 2) Create Firestore user profile (this should create the collection automatically)
            let data: [String: Any] = [
                "uid": user.uid,
                "name": name,
                "email": user.email ?? email,
                "createdAt": FieldValue.serverTimestamp(),
                "updatedAt": FieldValue.serverTimestamp()
            ]

            self.db.collection("users").document(user.uid).setData(data, merge: true) { err in
                self.setLoading(false)
                if let err = err {
                    // Surface the error so you see why it didn't write
                    return self.alert("Failed to save profile: \(err.localizedDescription)")
                }
                self.goHome()
            }
        }
    }

    @IBAction func signInLinkTapped(_ sender: UIButton) {
        performSegue(withIdentifier: "toSignIn", sender: nil)
    }

    // MARK: - Navigation

    private func goHome() {
        // Programmatic navigation only; remove storyboard segue to Home
        if let home = storyboard?.instantiateViewController(withIdentifier: "HomePageVC") as? HomePageVC {
            navigationController?.setViewControllers([home], animated: true)
        }
    }

    // MARK: - UI helpers

    private func setLoading(_ loading: Bool) {
        signUpButton.isEnabled = !loading
        signInLinkButton.isEnabled = !loading
        loading ? spinner.startAnimating() : spinner.stopAnimating()
    }

    private func alert(_ msg: String) {
        let ac = UIAlertController(title: "Sign Up", message: msg, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "OK", style: .default))
        present(ac, animated: true)
    }

    private func mapAuthError(_ error: Error) -> String {
        let ns = error as NSError
        guard let code = AuthErrorCode(rawValue: ns.code)?.code else {
            return error.localizedDescription
        }
        switch code {
        case .emailAlreadyInUse:   return "That email is already in use."
        case .invalidEmail:        return "That email looks invalid."
        case .weakPassword:        return "Password is too weak (min 6 chars)."
        case .userDisabled:        return "This account is disabled."
        case .userNotFound:        return "No account with that email."
        case .wrongPassword:       return "Incorrect password."
        default:                   return error.localizedDescription
        }
    }
}
