//
//  SignInVC.swift
//  Divvy-Alpha
//

import UIKit
import FirebaseAuth

class SignInVC: UIViewController {

    // Hook these up in IB
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var signInButton: UIButton!
    @IBOutlet weak var signUpLinkButton: UIButton!
    @IBOutlet weak var forgotPasswordButton: UIButton! // optional

    private let spinner = UIActivityIndicatorView(style: .medium)

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        passwordField.isSecureTextEntry = true

        spinner.hidesWhenStopped = true
        spinner.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(spinner)
        NSLayoutConstraint.activate([
            spinner.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            spinner.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
    }

    @IBAction func signInTapped(_ sender: UIButton) {
        view.endEditing(true)
        guard let email = emailField.text?.trimmingCharacters(in: .whitespacesAndNewlines), !email.isEmpty,
              let password = passwordField.text, !password.isEmpty else {
            return alert("Enter email and password.")
        }

        setLoading(true)
        Auth.auth().signIn(withEmail: email, password: password) { [weak self] _, error in
            guard let self = self else { return }
            self.setLoading(false)
            if let error = error { return self.alert(self.mapAuthError(error)) }
            self.goHome()
        }
    }

    @IBAction func signUpLinkTapped(_ sender: UIButton) {
        performSegue(withIdentifier: "toSignUp", sender: nil)
    }

    @IBAction func forgotPasswordTapped(_ sender: UIButton) {
        guard let email = emailField.text?.trimmingCharacters(in: .whitespacesAndNewlines), !email.isEmpty else {
            return alert("Enter your email first, then tap Forgot Password.")
        }
        Auth.auth().sendPasswordReset(withEmail: email) { [weak self] error in
            if let error = error { self?.alert(error.localizedDescription); return }
            self?.alert("Password reset email sent.")
        }
    }

    private func goHome() {
        performSegue(withIdentifier: "toHome", sender: nil)
        // Or programmatic:
        // if let home = storyboard?.instantiateViewController(withIdentifier: "HomePageVC") as? HomePageVC {
        //     navigationController?.setViewControllers([home], animated: true)
        // }
    }

    private func setLoading(_ loading: Bool) {
        signInButton.isEnabled = !loading
        signUpLinkButton.isEnabled = !loading
        forgotPasswordButton?.isEnabled = !loading
        loading ? spinner.startAnimating() : spinner.stopAnimating()
    }

    private func alert(_ msg: String) {
        let ac = UIAlertController(title: "Sign In", message: msg, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "OK", style: .default))
        present(ac, animated: true)
    }

    private func mapAuthError(_ error: Error) -> String {
        let ns = error as NSError
        // Wrap the NSError, then use the .code enum
        guard let code = AuthErrorCode(rawValue: ns.code)?.code else {
            return error.localizedDescription
        }
        switch code {
        case .emailAlreadyInUse:   return "That email is already in use."
        case .invalidEmail:        return "That email looks invalid."
        case .weakPassword:        return "Password is too weak (min 6 chars)."
        case .userDisabled:        return "This account is disabled."
        case .userNotFound:        return "No account with that email."
        case .wrongPassword:       return "Incorrect password."
        default:                   return error.localizedDescription
        }
    }
}

