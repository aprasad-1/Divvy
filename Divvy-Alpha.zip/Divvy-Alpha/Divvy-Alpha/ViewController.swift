//
//  ViewController.swift
//
//  ViewController.swift  (Sign Up)
//  Divvy-Alpha
//

import UIKit
import FirebaseAuth

class ViewController: UIViewController {

    // Hook these up in Interface Builder
    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var signUpButton: UIButton!
    @IBOutlet weak var signInLinkButton: UIButton!

    private let spinner = UIActivityIndicatorView(style: .medium)

    override func viewDidLoad() {
        super.viewDidLoad()

        // Optional logo you already had
        if view.viewWithTag(999) == nil {
            let imageView = UIImageView(image: UIImage(named: "DivvyLogo"))
            imageView.tag = 999
            imageView.contentMode = .scaleAspectFit
            imageView.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(imageView)
            // Pin above the title or wherever fits your layout
            NSLayoutConstraint.activate([
                imageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
                imageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 24),
                imageView.heightAnchor.constraint(equalToConstant: 48)
            ])
        }

        passwordField.isSecureTextEntry = true

        spinner.hidesWhenStopped = true
        spinner.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(spinner)
        NSLayoutConstraint.activate([
            spinner.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            spinner.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        // If already signed in, go straight to Home
        if Auth.auth().currentUser != nil {
            goHome()
        }
    }

    // MARK: - Actions

    @IBAction func signUpTapped(_ sender: UIButton) {
        view.endEditing(true)

        guard let name = nameField.text?.trimmingCharacters(in: .whitespacesAndNewlines), !name.isEmpty,
              let email = emailField.text?.trimmingCharacters(in: .whitespacesAndNewlines), !email.isEmpty,
              let password = passwordField.text, !password.isEmpty else {
            return alert("Please fill in name, email, and password.")
        }
        guard password.count >= 6 else { return alert("Password must be at least 6 characters.") }

        setLoading(true)
        Auth.auth().createUser(withEmail: email, password: password) { [weak self] result, error in
            guard let self = self else { return }
            self.setLoading(false)
            if let error = error { return self.alert(self.mapAuthError(error)) }

            // Save display name on the Firebase user profile
            let change = result?.user.createProfileChangeRequest()
            change?.displayName = name
            change?.commitChanges { _ in }

            self.goHome()
        }
    }

    @IBAction func signInLinkTapped(_ sender: UIButton) {
        performSegue(withIdentifier: "toSignIn", sender: nil)
    }

    // MARK: - Helpers

    private func goHome() {
        // If you wired a segue from this VC to HomePageVC:
        performSegue(withIdentifier: "toHome", sender: nil)
        // Or do it programmatically:
        // if let home = storyboard?.instantiateViewController(withIdentifier: "HomePageVC") as? HomePageVC {
        //     navigationController?.setViewControllers([home], animated: true)
        // }
    }

    private func setLoading(_ loading: Bool) {
        signUpButton.isEnabled = !loading
        signInLinkButton.isEnabled = !loading
        loading ? spinner.startAnimating() : spinner.stopAnimating()
    }

    private func alert(_ msg: String) {
        let ac = UIAlertController(title: "Sign Up", message: msg, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "OK", style: .default))
        present(ac, animated: true)
    }

    private func mapAuthError(_ error: Error) -> String {
        let ns = error as NSError
        // Wrap the NSError, then use the .code enum
        guard let code = AuthErrorCode(rawValue: ns.code)?.code else {
            return error.localizedDescription
        }
        switch code {
        case .emailAlreadyInUse:   return "That email is already in use."
        case .invalidEmail:        return "That email looks invalid."
        case .weakPassword:        return "Password is too weak (min 6 chars)."
        case .userDisabled:        return "This account is disabled."
        case .userNotFound:        return "No account with that email."
        case .wrongPassword:       return "Incorrect password."
        default:                   return error.localizedDescription
        }
    }
}

