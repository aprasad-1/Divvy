//
//  HomePageVC.swift
//  Divvy-Alpha
//

import UIKit
import FirebaseAuth

class HomePageVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        title = "Home"

        navigationItem.rightBarButtonItem = UIBarButtonItem(
            title: "Sign Out",
            style: .plain,
            target: self,
            action: #selector(signOutTapped)
        )
    }

    @objc private func signOutTapped() {
        try? Auth.auth().signOut()
        // Back to Sign In (clear stack)
        if let signIn = storyboard?.instantiateViewController(withIdentifier: "SignInVC") as? SignInVC {
            navigationController?.setViewControllers([signIn], animated: true)
        } else {
            navigationController?.popToRootViewController(animated: true)
        }
    }
}
